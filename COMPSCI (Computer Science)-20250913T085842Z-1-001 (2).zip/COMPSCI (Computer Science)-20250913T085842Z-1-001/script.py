import os
import re
import json
import pdfplumber   # pip install pdfplumber
import pandas as pd # pip install pandas
# -------------------------------
# 配置
# -------------------------------
PDF_FOLDER = r"C:\Users\zhiyu\Desktop\COMPSCI (Computer Science)-20250913T085842Z-1-001\COMPSCI (Computer Science)"
OUTPUT_FOLDER = r"C:\Users\zhiyu\Desktop\COMPSCI (Computer Science)-20250913T085842Z-1-001\parsed_output"

JSON_FILE = os.path.join(OUTPUT_FOLDER, "parsed_data.json")
CSV_FILE = os.path.join(OUTPUT_FOLDER, "parsed_data.csv")

# -------------------------------
# 清洗函数
# -------------------------------
def clean_text(text):
    if not text:
        return ""
    # 去掉换行、重复空格
    text = text.replace("\n", " ").replace("\r", " ")
    text = re.sub(r"\s+", " ", text)

    # 去掉页码（常见情况：单独一行是数字）
    text = re.sub(r"\bPage\s*\d+\b", "", text, flags=re.IGNORECASE)
    text = re.sub(r"^\d+\s*$", "", text, flags=re.MULTILINE)

    # 去掉特殊符号
    text = re.sub(r"[•·●▪■]", "", text)
    return text.strip()

# -------------------------------
# 分块函数（按课程/周次/Deadline）
# -------------------------------
def split_sections(text, course_name="Unknown"):
    sections = []
    # 用正则匹配 Week / Deadline / Assignment 等关键字
    pattern = re.compile(r"(Week\s*\d+|Deadline.*|Assignment\s*\d+)", re.IGNORECASE)

    parts = pattern.split(text)
    # parts = [前言, "Week 1", 内容1, "Week 2", 内容2, "Deadline", 内容3...]

    current_section = "Introduction"
    buffer = ""

    for part in parts:
        if pattern.match(part):
            # 保存上一段
            if buffer.strip():
                sections.append((current_section, buffer.strip()))
            # 更新 section 标题
            current_section = part.strip()
            buffer = ""
        else:
            buffer += " " + part

    # 最后一段
    if buffer.strip():
        sections.append((current_section, buffer.strip()))

    return [
        {
            "id": f"{course_name}_{i+1}",
            "course": course_name,
            "section": sec,
            "text": txt
        }
        for i, (sec, txt) in enumerate(sections)
    ]

# -------------------------------
# 解析 PDF
# -------------------------------
def parse_pdf(file_path):
    course_name = os.path.splitext(os.path.basename(file_path))[0]  # 用文件名当课程名
    text_all = ""
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text_all += page_text + " "
    return split_sections(clean_text(text_all), course_name)

# -------------------------------
# 主程序
# -------------------------------
def main():
    if not os.path.exists(OUTPUT_FOLDER):
        os.makedirs(OUTPUT_FOLDER)

    all_data = []
    pdf_files = [f for f in os.listdir(PDF_FOLDER) if f.lower().endswith(".pdf")]

    for pdf_file in pdf_files:
        file_path = os.path.join(PDF_FOLDER, pdf_file)
        print(f"Parsing {pdf_file} ...")
        records = parse_pdf(file_path)
        all_data.extend(records)

    # 保存 JSON
    with open(JSON_FILE, "w", encoding="utf-8") as f:
        json.dump(all_data, f, ensure_ascii=False, indent=2)

    # 保存 CSV
    df = pd.DataFrame(all_data)
    df.to_csv(CSV_FILE, index=False, encoding="utf-8")

    print(f"✅ Done! {len(pdf_files)} PDFs parsed, {len(all_data)} sections saved.")
    print(f"👉 JSON: {JSON_FILE}")
    print(f"👉 CSV:  {CSV_FILE}")

# -------------------------------
# 执行
# -------------------------------
if __name__ == "__main__":
    main()